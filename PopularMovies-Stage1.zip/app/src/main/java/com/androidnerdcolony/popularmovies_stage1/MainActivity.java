package com.androidnerdcolony.popularmovies_stage1;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.androidnerdcolony.popularmovies_stage1.data.Movie;
import com.androidnerdcolony.popularmovies_stage1.data.MovieUtil;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final String LOG_TAG = MainActivity.class.getSimpleName();
    private RecyclerView mRecyclerView;
    private List<Movie> mMovies;
    private int mSortBy;
    private Context mContext;
    private SharedPreferences mPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = this;
        mRecyclerView = (RecyclerView) findViewById(R.id.bible_text_recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mPreferences = this.getPreferences(Context.MODE_PRIVATE);
        String[] sortByList = getResources().getStringArray(R.array.sort_by);

        mSortBy = mPreferences.getInt("sortBy", 1);

        ArrayAdapter<String> sortByAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, sortByList);
        Spinner sortBySpinner = (Spinner) findViewById(R.id.movie_list_sort_by);
        sortBySpinner.setAdapter(sortByAdapter);
        sortBySpinner.setSelection(mSortBy);
        sortBySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                mSortBy = position;
                SharedPreferences.Editor editor = mPreferences.edit();
                editor.putInt("sortBy", mSortBy);
                editor.apply();
                new makeQuery().execute();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });


    }

    private class makeQuery extends AsyncTask<Void, Void, List<Movie>> {

        @Override
        protected List<Movie> doInBackground(Void... voids) {
            String[] sortByList = getResources().getStringArray(R.array.sort_by);
            String sortByString = sortByList[mSortBy];
            mMovies = new MovieUtil(mContext).getMovies(sortByString);
            return mMovies;
        }

        @Override
        protected void onPostExecute(List<Movie> movies) {
            super.onPostExecute(movies);
            mMovies = movies;

            RecyclerView.LayoutManager layoutManager = new GridLayoutManager(mContext, 3);
            mRecyclerView.setLayoutManager(layoutManager);
            RecyclerView.Adapter adapter = new MovieRecyclerAdapter(mContext, mMovies);
            mRecyclerView.setItemAnimator(new DefaultItemAnimator());
            mRecyclerView.setAdapter(adapter);
        }
    }
}
